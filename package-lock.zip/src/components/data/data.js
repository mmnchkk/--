import RickImg from '../../img/rick.png'

export const characters = [
    {
        image: RickImg,
        name:"Rick sanchez",
    },
    {
        image: RickImg,
        name:"Rick sanchez",
    },
    {
        image: RickImg,
        name:"Rick sanchez",
    },
    {
        image: RickImg,
        name:"Rick sanchez",
    },
    {
        image: RickImg,
        name:"Rick sanchez",
    },
    {
        image: RickImg,
        name:"Rick sanchez",
    },
]

