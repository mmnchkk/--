import "./input.css"

function Input() {
    return (
      <div className = "search">
        <label htmlFor="search">Search</label>
        <input type = "text" placeholder="Найти"/>
      </div>
    );
  }
  
  export default Input;
  